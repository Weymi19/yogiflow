import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Pose, Sequence, User, ViewState, PoseCategory } from './types';
import { StorageService } from './services/storage';
import { LibraryView } from './views/LibraryView';
import { BuilderView } from './views/BuilderView';
import { DashboardView } from './views/DashboardView';
import { PlayerView } from './views/PlayerView';
import { Loader2 } from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('dashboard');
  const [poses, setPoses] = useState<Pose[]>([]);
  const [sequences, setSequences] = useState<Sequence[]>([]);
  const [user, setUser] = useState<User | null>(null);
  const [activeSequence, setActiveSequence] = useState<Sequence | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize Data
  useEffect(() => {
    const loadedPoses = StorageService.getPoses();
    const loadedSequences = StorageService.getSequences();
    const loadedUser = StorageService.getUser();

    setPoses(loadedPoses);
    setSequences(loadedSequences);
    setUser(loadedUser);
    setIsLoading(false);

    // Check for shared data in URL hash
    const hash = window.location.hash;
    if (hash.startsWith('#share=')) {
      try {
        const shareData = hash.replace('#share=', '');
        const decoded = JSON.parse(atob(decodeURIComponent(shareData)));
        if (decoded && decoded.id && decoded.poses) {
          console.log("Found shared sequence:", decoded);
          // Set as active sequence and go to player immediately
          setActiveSequence(decoded);
          setView('player');
        }
      } catch (e) {
        console.error("Failed to parse shared sequence", e);
      }
    }
  }, []);

  // Persistence
  useEffect(() => {
    if (!isLoading) {
      StorageService.savePoses(poses);
      StorageService.saveSequences(sequences);
    }
  }, [poses, sequences, isLoading]);

  const handleCreateSequence = () => {
    setActiveSequence(null); // Clear active to start fresh
    setView('builder');
  };

  const handleEditSequence = (seq: Sequence) => {
    setActiveSequence(seq);
    setView('builder');
  };

  const handlePlaySequence = (seq: Sequence) => {
    setActiveSequence(seq);
    setView('player');
  };

  const handleDeleteSequence = (id: string) => {
    if (window.confirm("Are you sure you want to delete this sequence?")) {
      setSequences(prev => prev.filter(s => s.id !== id));
    }
  };

  const handleSaveSequence = (seq: Sequence) => {
    setSequences(prev => {
      const exists = prev.findIndex(s => s.id === seq.id);
      if (exists >= 0) {
        const newSeq = [...prev];
        newSeq[exists] = seq;
        return newSeq;
      } else {
        return [...prev, seq];
      }
    });
    setView('dashboard');
  };

  const handleAddPose = (pose: Pose) => {
    setPoses(prev => [...prev, pose]);
  };
  
  const handleUpdatePose = (pose: Pose) => {
     setPoses(prev => prev.map(p => p.id === pose.id ? pose : p));
  };

  const handleDeletePose = (id: string) => {
    if(window.confirm("Delete this pose? It will remain in existing sequences but be removed from the library.")) {
        setPoses(prev => prev.filter(p => p.id !== id));
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 text-teal-600">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <Layout currentView={view} onNavigate={setView}>
      {view === 'dashboard' && (
        <DashboardView 
          sequences={sequences} 
          onCreate={handleCreateSequence}
          onEdit={handleEditSequence}
          onPlay={handlePlaySequence}
          onDelete={handleDeleteSequence}
        />
      )}
      {view === 'library' && (
        <LibraryView 
          poses={poses} 
          onAddPose={handleAddPose} 
          onUpdatePose={handleUpdatePose}
          onDeletePose={handleDeletePose}
        />
      )}
      {view === 'builder' && (
        <BuilderView 
          initialSequence={activeSequence} 
          allPoses={poses}
          onSave={handleSaveSequence}
          onCancel={() => setView('dashboard')}
          onAddPoseToLibrary={handleAddPose}
        />
      )}
      {view === 'player' && activeSequence && (
        <PlayerView 
          sequence={activeSequence} 
          onBack={() => setView('dashboard')}
        />
      )}
      {view === 'player' && !activeSequence && (
        <div className="text-center mt-20">
          <p className="text-slate-500">No active sequence loaded.</p>
          <button onClick={() => setView('dashboard')} className="text-teal-600 underline mt-2">Go Home</button>
        </div>
      )}
    </Layout>
  );
};

export default App;