import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AIPoseSuggestion, PoseCategory } from "../types";

// Safety check for API key availability
const getAIClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("Gemini API Key is missing. AI features will be disabled.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const suggestPoseDetails = async (poseName: string): Promise<AIPoseSuggestion | null> => {
  const ai = getAIClient();
  if (!ai) return null;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Provide detailed yoga information for the pose: "${poseName}". 
      If the pose is not a standard yoga pose, provide a best guess based on the name or generic fitness instruction.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            description: { type: Type.STRING, description: "A short description of what the pose is." },
            cues: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "3-5 clear, actionable instructional cues for the student."
            },
            category: { 
              type: Type.STRING, 
              enum: Object.values(PoseCategory),
              description: "The category the pose belongs to."
            },
            sanskritName: { type: Type.STRING, description: "The Sanskrit name if applicable." },
            benefits: { type: Type.STRING, description: "Physical or mental benefits of the pose." }
          },
          required: ["description", "cues", "category", "sanskritName", "benefits"]
        } as Schema
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as AIPoseSuggestion;
    }
    return null;
  } catch (error) {
    console.error("Error fetching pose details from Gemini:", error);
    return null;
  }
};

export const suggestSequencePlan = async (goal: string, durationMin: number): Promise<{ title: string, description: string, poseNames: string[] } | null> => {
    const ai = getAIClient();
    if (!ai) return null;
  
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Create a yoga sequence plan for: "${goal}". Target duration: ${durationMin} minutes.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              poseNames: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING },
                description: "A list of standard yoga pose names in order."
              }
            }
          } as Schema
        }
      });
  
      if (response.text) {
        return JSON.parse(response.text);
      }
      return null;
    } catch (error) {
      console.error("Error planning sequence:", error);
      return null;
    }
  };