import { Pose, Sequence, User, PoseCategory } from "../types";

const STORAGE_KEYS = {
  POSES: 'yogiflow_poses',
  SEQUENCES: 'yogiflow_sequences',
  USER: 'yogiflow_user',
};

// Initial Seed Data
const DEFAULT_POSES: Pose[] = [
  {
    id: 'p1',
    name: 'Mountain Pose',
    sanskritName: 'Tadasana',
    category: PoseCategory.Standing,
    imageUrl: 'https://images.unsplash.com/photo-1544367563-12123d8250bd?auto=format&fit=crop&q=80&w=400',
    cues: ['Feet together or hip-width apart', 'Ground through all four corners of feet', 'Engage quads, lift kneecaps', 'Shoulders down and back'],
    benefits: 'Improves posture, strengthens thighs, knees, and ankles.'
  },
  {
    id: 'p2',
    name: 'Downward Facing Dog',
    sanskritName: 'Adho Mukha Svanasana',
    category: PoseCategory.Inversion,
    imageUrl: 'https://images.unsplash.com/photo-1544367563-12123d8250bd?auto=format&fit=crop&q=80&w=400', // Using placeholder for demo
    cues: ['Hands shoulder-width apart', 'Feet hip-width apart', 'Lift hips high', 'Press chest towards thighs', 'Relax neck'],
    benefits: 'Calms the brain, energizes the body, stretches shoulders, hamstrings, calves.'
  },
  {
    id: 'p3',
    name: 'Warrior II',
    sanskritName: 'Virabhadrasana II',
    category: PoseCategory.Standing,
    imageUrl: 'https://images.unsplash.com/photo-1544367563-12123d8250bd?auto=format&fit=crop&q=80&w=400',
    cues: ['Front knee stacked over ankle', 'Back leg strong and straight', 'Arms parallel to floor', 'Gaze over front middle finger'],
    benefits: 'Strengthens and stretches legs and ankles, stretches groins, chest and lungs, shoulders.'
  }
];

export const StorageService = {
  getPoses: (): Pose[] => {
    const data = localStorage.getItem(STORAGE_KEYS.POSES);
    return data ? JSON.parse(data) : DEFAULT_POSES;
  },

  savePoses: (poses: Pose[]) => {
    localStorage.setItem(STORAGE_KEYS.POSES, JSON.stringify(poses));
  },

  getSequences: (): Sequence[] => {
    const data = localStorage.getItem(STORAGE_KEYS.SEQUENCES);
    return data ? JSON.parse(data) : [];
  },

  saveSequences: (sequences: Sequence[]) => {
    localStorage.setItem(STORAGE_KEYS.SEQUENCES, JSON.stringify(sequences));
  },

  getUser: (): User => {
    const data = localStorage.getItem(STORAGE_KEYS.USER);
    return data ? JSON.parse(data) : { id: 'u1', name: 'Yogi One', email: 'yogi@example.com' };
  },

  saveUser: (user: User) => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  }
};