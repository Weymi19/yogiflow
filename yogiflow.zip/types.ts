export interface Pose {
  id: string;
  name: string;
  sanskritName?: string;
  category: PoseCategory;
  imageUrl: string;
  cues: string[];
  benefits?: string;
  notes?: string;
}

export enum PoseCategory {
  WarmUp = 'Warm Up',
  Standing = 'Standing',
  Sitting = 'Sitting',
  Balancing = 'Balancing',
  Inversion = 'Inversion',
  Backbend = 'Backbend',
  Core = 'Core',
  Restorative = 'Restorative',
  Flow = 'Flow',
  Other = 'Other'
}

export interface Sequence {
  id: string;
  title: string;
  description: string;
  authorId: string;
  createdAt: number;
  updatedAt: number;
  poses: SequencePose[]; // Ordered list
  isPublic: boolean;
}

export interface SequencePose extends Pose {
  instanceId: string; // Unique ID for this specific instance in the sequence (allows duplicates)
  durationSeconds?: number; // Optional duration for this step
  customCues?: string; // Overridden cues for this specific sequence
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
}

export type ViewState = 'dashboard' | 'builder' | 'library' | 'player' | 'shared';

// For the AI Service
export interface AIPoseSuggestion {
  description: string;
  cues: string[];
  category: PoseCategory;
  sanskritName: string;
  benefits: string;
}