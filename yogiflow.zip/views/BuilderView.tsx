import React, { useState, useEffect } from 'react';
import { Pose, Sequence, SequencePose } from '../types';
import { Button } from '../components/Button';
import { Plus, Save, ArrowLeft, GripVertical, X, Clock, AlertCircle, Wand2 } from 'lucide-react';
import { suggestSequencePlan } from '../services/gemini';

interface BuilderViewProps {
  initialSequence: Sequence | null;
  allPoses: Pose[];
  onSave: (seq: Sequence) => void;
  onCancel: () => void;
  onAddPoseToLibrary: (pose: Pose) => void;
}

export const BuilderView: React.FC<BuilderViewProps> = ({ initialSequence, allPoses, onSave, onCancel }) => {
  const [title, setTitle] = useState(initialSequence?.title || "My New Flow");
  const [description, setDescription] = useState(initialSequence?.description || "");
  const [selectedPoses, setSelectedPoses] = useState<SequencePose[]>(initialSequence?.poses || []);
  const [searchTerm, setSearchTerm] = useState("");
  const [isAIGenerating, setIsAIGenerating] = useState(false);

  // Filter poses in library
  const filteredLibrary = allPoses.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddPose = (pose: Pose) => {
    const newPose: SequencePose = {
      ...pose,
      instanceId: Math.random().toString(36).substr(2, 9),
      durationSeconds: 60, // Default duration
    };
    setSelectedPoses([...selectedPoses, newPose]);
  };

  const handleRemovePose = (index: number) => {
    const newPoses = [...selectedPoses];
    newPoses.splice(index, 1);
    setSelectedPoses(newPoses);
  };

  const handleMovePose = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === selectedPoses.length - 1) return;

    const newPoses = [...selectedPoses];
    const temp = newPoses[index];
    newPoses[index] = newPoses[index + (direction === 'up' ? -1 : 1)];
    newPoses[index + (direction === 'up' ? -1 : 1)] = temp;
    setSelectedPoses(newPoses);
  };

  const handleSave = () => {
    if (!title.trim()) return alert("Please enter a title");
    if (selectedPoses.length === 0) return alert("Please add at least one pose");

    const newSequence: Sequence = {
      id: initialSequence?.id || Math.random().toString(36).substr(2, 9),
      title,
      description,
      authorId: 'u1',
      createdAt: initialSequence?.createdAt || Date.now(),
      updatedAt: Date.now(),
      poses: selectedPoses,
      isPublic: initialSequence?.isPublic || false
    };
    onSave(newSequence);
  };

  const handleAIGenerate = async () => {
    const userPrompt = window.prompt("Describe the goal of this sequence (e.g., 'Morning energy for stiff back')");
    if (!userPrompt) return;

    setIsAIGenerating(true);
    const plan = await suggestSequencePlan(userPrompt, 20);
    setIsAIGenerating(false);

    if (plan) {
        setTitle(plan.title);
        setDescription(plan.description);
        
        // Try to match returned names to existing library poses
        // If not found, we could fetch them or just show a warning. 
        // For simplicity, we only add if found in library, or maybe add a placeholder?
        // Let's strict match for now or partial match.
        const foundPoses: SequencePose[] = [];
        
        plan.poseNames.forEach(name => {
            const match = allPoses.find(p => p.name.toLowerCase().includes(name.toLowerCase()));
            if (match) {
                foundPoses.push({
                    ...match,
                    instanceId: Math.random().toString(36).substr(2, 9),
                    durationSeconds: 60
                });
            }
        });

        if (foundPoses.length > 0) {
            setSelectedPoses(foundPoses);
        } else {
            alert("AI suggested poses but couldn't find matches in your library. Try adding more poses to your library first!");
        }
    } else {
        alert("Could not generate sequence. Check API Key or try again.");
    }
  };

  return (
    <div className="h-[calc(100vh-100px)] flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 flex-shrink-0">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onCancel} className="!p-2">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex flex-col">
            <input 
              type="text" 
              value={title} 
              onChange={(e) => setTitle(e.target.value)}
              className="text-2xl font-bold bg-transparent border-none focus:ring-0 placeholder-slate-300 text-slate-800 p-0"
              placeholder="Sequence Title"
            />
            <input 
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="text-sm text-slate-500 bg-transparent border-none focus:ring-0 placeholder-slate-300 w-96 p-0"
              placeholder="Add a short description..."
            />
          </div>
        </div>
        <div className="flex gap-2">
           <Button variant="secondary" onClick={handleAIGenerate} disabled={isAIGenerating}>
              <Wand2 className="w-4 h-4 mr-2" />
              {isAIGenerating ? "Thinking..." : "AI Auto-Fill"}
           </Button>
           <Button onClick={handleSave}>
            <Save className="w-4 h-4 mr-2" />
            Save Sequence
          </Button>
        </div>
      </div>

      {/* Main Builder Area */}
      <div className="flex-1 flex gap-6 overflow-hidden">
        
        {/* Left: Library */}
        <div className="w-1/3 flex flex-col bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-100 bg-slate-50">
                <h3 className="font-semibold text-slate-700 mb-2">Pose Library</h3>
                <input 
                  type="text" 
                  placeholder="Search poses..." 
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {filteredLibrary.map(pose => (
                    <div key={pose.id} className="group flex items-center gap-3 p-2 hover:bg-slate-50 rounded-lg border border-transparent hover:border-slate-200 transition-all cursor-pointer" onClick={() => handleAddPose(pose)}>
                        <img src={pose.imageUrl} alt={pose.name} className="w-12 h-12 rounded-md object-cover bg-slate-200" />
                        <div className="flex-1">
                            <p className="font-medium text-slate-700 text-sm">{pose.name}</p>
                            <p className="text-xs text-slate-400">{pose.category}</p>
                        </div>
                        <Button size="sm" variant="ghost" className="opacity-0 group-hover:opacity-100">
                            <Plus className="w-4 h-4" />
                        </Button>
                    </div>
                ))}
                {filteredLibrary.length === 0 && (
                    <div className="text-center py-8 text-slate-400 text-sm">
                        No poses found.
                    </div>
                )}
            </div>
        </div>

        {/* Right: Timeline/Sequence */}
        <div className="flex-1 flex flex-col bg-slate-100 rounded-xl border-2 border-dashed border-slate-300 overflow-hidden relative">
             <div className="p-4 bg-white/50 border-b border-slate-200 flex justify-between items-center backdrop-blur-sm">
                <h3 className="font-semibold text-slate-700">Timeline ({selectedPoses.length} Poses)</h3>
                <span className="text-xs font-mono text-slate-500 bg-slate-200 px-2 py-1 rounded">
                    Total: {Math.ceil(selectedPoses.reduce((acc, p) => acc + (p.durationSeconds || 0), 0) / 60)} min
                </span>
             </div>
             
             <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {selectedPoses.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-400">
                        <GripVertical className="w-12 h-12 mb-4 opacity-20" />
                        <p>Drag poses here or click + from library</p>
                    </div>
                ) : (
                    selectedPoses.map((pose, index) => (
                        <div key={pose.instanceId} className="bg-white p-3 rounded-lg shadow-sm border border-slate-200 flex items-center gap-4 animate-in fade-in slide-in-from-bottom-2">
                            <div className="flex flex-col gap-1 text-slate-300">
                                <button onClick={() => handleMovePose(index, 'up')} disabled={index === 0} className="hover:text-teal-600 disabled:opacity-30">▲</button>
                                <button onClick={() => handleMovePose(index, 'down')} disabled={index === selectedPoses.length - 1} className="hover:text-teal-600 disabled:opacity-30">▼</button>
                            </div>
                            <span className="text-slate-400 font-mono text-xs w-6">{index + 1}</span>
                            <img src={pose.imageUrl} alt="" className="w-12 h-12 rounded bg-slate-200 object-cover" />
                            <div className="flex-1">
                                <p className="font-medium text-slate-800">{pose.name}</p>
                                <div className="flex items-center gap-2 mt-1">
                                    <Clock className="w-3 h-3 text-slate-400" />
                                    <input 
                                        type="number" 
                                        className="w-12 text-xs border border-slate-200 rounded px-1 py-0.5" 
                                        value={pose.durationSeconds}
                                        onChange={(e) => {
                                            const newPoses = [...selectedPoses];
                                            newPoses[index].durationSeconds = parseInt(e.target.value) || 0;
                                            setSelectedPoses(newPoses);
                                        }}
                                    />
                                    <span className="text-xs text-slate-400">sec</span>
                                </div>
                            </div>
                            <div className="flex-1">
                                <input 
                                    type="text" 
                                    placeholder="Add custom cue..."
                                    className="w-full text-xs border-b border-transparent hover:border-slate-200 focus:border-teal-500 bg-transparent focus:outline-none py-1"
                                    value={pose.customCues || ""}
                                    onChange={(e) => {
                                        const newPoses = [...selectedPoses];
                                        newPoses[index].customCues = e.target.value;
                                        setSelectedPoses(newPoses);
                                    }}
                                />
                            </div>
                            <button onClick={() => handleRemovePose(index)} className="text-slate-400 hover:text-red-500">
                                <X className="w-5 h-5" />
                            </button>
                        </div>
                    ))
                )}
             </div>
        </div>
      </div>
    </div>
  );
};