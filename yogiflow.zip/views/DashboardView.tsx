import React from 'react';
import { Sequence } from '../types';
import { Button } from '../components/Button';
import { Play, Edit, Trash2, Clock, Share2, Plus } from 'lucide-react';

interface DashboardProps {
  sequences: Sequence[];
  onCreate: () => void;
  onEdit: (seq: Sequence) => void;
  onPlay: (seq: Sequence) => void;
  onDelete: (id: string) => void;
}

export const DashboardView: React.FC<DashboardProps> = ({ sequences, onCreate, onEdit, onPlay, onDelete }) => {
  
  const handleShare = (seq: Sequence) => {
    // Basic serialization for sharing
    const data = JSON.stringify(seq);
    const encoded = encodeURIComponent(btoa(data));
    const url = `${window.location.origin}${window.location.pathname}#share=${encoded}`;
    
    navigator.clipboard.writeText(url).then(() => {
      alert("Share link copied to clipboard! Anyone with this link can view this sequence.");
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-800">My Sequences</h2>
          <p className="text-slate-500 mt-1">Manage and organize your yoga flows</p>
        </div>
        <Button onClick={onCreate} className="shadow-lg shadow-teal-600/20">
          <Plus className="w-4 h-4 mr-2" />
          Create New Sequence
        </Button>
      </div>

      {sequences.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-slate-200">
          <div className="bg-teal-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Plus className="w-8 h-8 text-teal-600" />
          </div>
          <h3 className="text-lg font-medium text-slate-800">No sequences yet</h3>
          <p className="text-slate-500 mb-6 max-w-sm mx-auto">Start building your first custom yoga flow by clicking the button above.</p>
          <Button onClick={onCreate} variant="secondary">Create Sequence</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sequences.map(seq => (
            <div key={seq.id} className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all duration-200 flex flex-col overflow-hidden group">
              <div className="p-6 flex-1">
                <div className="flex justify-between items-start mb-4">
                    <h3 className="font-bold text-lg text-slate-800 line-clamp-1" title={seq.title}>{seq.title}</h3>
                    {seq.isPublic && <span className="text-[10px] uppercase bg-teal-100 text-teal-700 px-2 py-0.5 rounded-full font-bold">Public</span>}
                </div>
                <p className="text-slate-500 text-sm mb-4 line-clamp-2 min-h-[2.5em]">{seq.description || "No description provided."}</p>
                
                <div className="flex items-center text-xs text-slate-400 gap-4 mb-4">
                  <div className="flex items-center gap-1">
                    <span className="font-semibold text-slate-600">{seq.poses.length}</span> Poses
                  </div>
                  <div className="flex items-center gap-1">
                     {/* Rough estimate: 3 mins per pose? maybe less. Lets say user defined or default 1 min */}
                    <Clock className="w-3 h-3" />
                    <span>~{Math.ceil(seq.poses.reduce((acc, p) => acc + (p.durationSeconds || 60), 0) / 60)} min</span>
                  </div>
                </div>

                {/* Preview of poses (thumbnails) */}
                <div className="flex -space-x-2 overflow-hidden py-2">
                  {seq.poses.slice(0, 5).map((p, i) => (
                    <img 
                      key={i} 
                      src={p.imageUrl} 
                      alt={p.name}
                      className="w-8 h-8 rounded-full border-2 border-white object-cover bg-slate-200"
                    />
                  ))}
                  {seq.poses.length > 5 && (
                    <div className="w-8 h-8 rounded-full border-2 border-white bg-slate-100 flex items-center justify-center text-[10px] text-slate-500 font-medium">
                      +{seq.poses.length - 5}
                    </div>
                  )}
                </div>
              </div>

              <div className="border-t border-slate-100 p-4 bg-slate-50 flex items-center justify-between gap-2">
                 <Button onClick={() => onPlay(seq)} size="sm" className="flex-1">
                    <Play className="w-3 h-3 mr-2" /> Start
                 </Button>
                 
                 <div className="flex items-center gap-1">
                    <button 
                      onClick={() => onEdit(seq)} 
                      className="p-2 text-slate-500 hover:text-teal-600 hover:bg-white rounded-lg transition-colors"
                      title="Edit"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => handleShare(seq)} 
                      className="p-2 text-slate-500 hover:text-blue-600 hover:bg-white rounded-lg transition-colors"
                      title="Share Link"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => onDelete(seq.id)} 
                      className="p-2 text-slate-500 hover:text-red-600 hover:bg-white rounded-lg transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                 </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};