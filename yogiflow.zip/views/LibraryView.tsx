import React, { useState } from 'react';
import { Pose, PoseCategory } from '../types';
import { Button } from '../components/Button';
import { suggestPoseDetails } from '../services/gemini';
import { Search, Plus, Trash2, Wand2, Loader2, Edit2, X } from 'lucide-react';

interface LibraryViewProps {
  poses: Pose[];
  onAddPose: (pose: Pose) => void;
  onUpdatePose: (pose: Pose) => void;
  onDeletePose: (id: string) => void;
}

export const LibraryView: React.FC<LibraryViewProps> = ({ poses, onAddPose, onUpdatePose, onDeletePose }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPose, setEditingPose] = useState<Pose | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("All");

  // Form State
  const [formData, setFormData] = useState<Partial<Pose>>({
    name: '',
    category: PoseCategory.Other,
    imageUrl: '',
    cues: [],
    benefits: ''
  });
  const [isAiLoading, setIsAiLoading] = useState(false);

  const filteredPoses = poses.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === "All" || p.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const handleOpenModal = (pose?: Pose) => {
    if (pose) {
        setEditingPose(pose);
        setFormData({ ...pose });
    } else {
        setEditingPose(null);
        setFormData({
            name: '',
            category: PoseCategory.Other,
            imageUrl: '',
            cues: [],
            benefits: ''
        });
    }
    setIsModalOpen(true);
  };

  const handleAiFill = async () => {
    if (!formData.name) return alert("Please enter a pose name first.");
    setIsAiLoading(true);
    const details = await suggestPoseDetails(formData.name);
    setIsAiLoading(false);

    if (details) {
      setFormData(prev => ({
        ...prev,
        ...details,
        // Keep existing image if present, otherwise use placeholder logic could go here but simple is better
        imageUrl: prev.imageUrl || `https://source.unsplash.com/random/400x400/?yoga,${details.category}`
      }));
    } else {
        alert("Could not fetch details. Please fill manually.");
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    const pose: Pose = {
      id: editingPose ? editingPose.id : Math.random().toString(36).substr(2, 9),
      name: formData.name,
      sanskritName: formData.sanskritName,
      category: formData.category as PoseCategory,
      imageUrl: formData.imageUrl || 'https://via.placeholder.com/400?text=Yoga+Pose', // Fallback
      cues: Array.isArray(formData.cues) ? formData.cues : [],
      benefits: formData.benefits
    };

    if (editingPose) {
        onUpdatePose(pose);
    } else {
        onAddPose(pose);
    }
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h2 className="text-3xl font-bold text-slate-800">Pose Library</h2>
        <Button onClick={() => handleOpenModal()}>
          <Plus className="w-4 h-4 mr-2" /> Add Pose
        </Button>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
          <input 
            type="text" 
            placeholder="Search poses..." 
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <select 
          className="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
          value={filterCategory}
          onChange={(e) => setFilterCategory(e.target.value)}
        >
          <option value="All">All Categories</option>
          {Object.values(PoseCategory).map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
        {filteredPoses.map(pose => (
          <div key={pose.id} className="group relative bg-white rounded-xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-md transition-all">
            <div className="aspect-square bg-slate-100 relative">
               <img src={pose.imageUrl} alt={pose.name} className="w-full h-full object-cover" loading="lazy" />
               <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                 <button onClick={() => handleOpenModal(pose)} className="p-2 bg-white rounded-full hover:scale-110 transition-transform"><Edit2 className="w-4 h-4 text-teal-600"/></button>
                 <button onClick={() => onDeletePose(pose.id)} className="p-2 bg-white rounded-full hover:scale-110 transition-transform"><Trash2 className="w-4 h-4 text-red-500"/></button>
               </div>
            </div>
            <div className="p-3">
              <h3 className="font-bold text-slate-800 text-sm truncate">{pose.name}</h3>
              <p className="text-xs text-slate-500 truncate">{pose.sanskritName || '-'}</p>
              <span className="inline-block mt-2 px-2 py-0.5 bg-slate-100 text-slate-600 text-[10px] rounded-full uppercase tracking-wide">
                {pose.category}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center sticky top-0 bg-white z-10">
              <h3 className="text-xl font-bold text-slate-800">{editingPose ? 'Edit Pose' : 'Add New Pose'}</h3>
              <button onClick={() => setIsModalOpen(false)}><X className="w-6 h-6 text-slate-400" /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Pose Name</label>
                <div className="flex gap-2">
                    <input 
                        required
                        type="text" 
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none"
                        placeholder="e.g. Tree Pose"
                    />
                    <Button type="button" variant="secondary" onClick={handleAiFill} disabled={isAiLoading || !formData.name}>
                        {isAiLoading ? <Loader2 className="w-4 h-4 animate-spin"/> : <Wand2 className="w-4 h-4" />}
                    </Button>
                </div>
                <p className="text-xs text-slate-500 mt-1">Tip: Enter name and click wand to auto-fill details.</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
                    <select 
                        value={formData.category}
                        onChange={(e) => setFormData({...formData, category: e.target.value as PoseCategory})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg outline-none"
                    >
                        {Object.values(PoseCategory).map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Sanskrit Name</label>
                    <input 
                        type="text" 
                        value={formData.sanskritName || ''}
                        onChange={(e) => setFormData({...formData, sanskritName: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg outline-none"
                    />
                 </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Image URL</label>
                <input 
                    type="url" 
                    value={formData.imageUrl || ''}
                    onChange={(e) => setFormData({...formData, imageUrl: e.target.value})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg outline-none"
                    placeholder="https://..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Cues (one per line)</label>
                <textarea 
                    rows={4}
                    value={formData.cues?.join('\n')}
                    onChange={(e) => setFormData({...formData, cues: e.target.value.split('\n')})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg outline-none"
                    placeholder="Keep back straight&#10;Breathe deeply"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Benefits</label>
                <textarea 
                    rows={2}
                    value={formData.benefits || ''}
                    onChange={(e) => setFormData({...formData, benefits: e.target.value})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg outline-none"
                />
              </div>

              <div className="pt-4 flex justify-end gap-3">
                <Button type="button" variant="ghost" onClick={() => setIsModalOpen(false)}>Cancel</Button>
                <Button type="submit">Save Pose</Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};