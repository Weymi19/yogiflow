import React, { useState, useEffect } from 'react';
import { Sequence } from '../types';
import { Button } from '../components/Button';
import { X, ChevronLeft, ChevronRight, Pause, Play, RefreshCw, Volume2, Info } from 'lucide-react';

interface PlayerViewProps {
  sequence: Sequence;
  onBack: () => void;
}

export const PlayerView: React.FC<PlayerViewProps> = ({ sequence, onBack }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [timer, setTimer] = useState(sequence.poses[0]?.durationSeconds || 60);
  const [showInfo, setShowInfo] = useState(true);

  const currentPose = sequence.poses[currentIndex];
  const nextPose = sequence.poses[currentIndex + 1];

  useEffect(() => {
    setTimer(currentPose?.durationSeconds || 60);
    setIsPlaying(false);
  }, [currentIndex, currentPose]);

  useEffect(() => {
    let interval: any;
    if (isPlaying && timer > 0) {
      interval = setInterval(() => {
        setTimer((t) => t - 1);
      }, 1000);
    } else if (timer === 0 && isPlaying) {
      // Auto advance or play chime? 
      // For now just stop.
      setIsPlaying(false);
      // Optional: Auto advance
      // if (currentIndex < sequence.poses.length - 1) handleNext();
    }
    return () => clearInterval(interval);
  }, [isPlaying, timer]);

  const handleNext = () => {
    if (currentIndex < sequence.poses.length - 1) {
      setCurrentIndex(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  };

  const toggleTimer = () => setIsPlaying(!isPlaying);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // Text-to-speech Cue Reading
  const speakCues = () => {
    if ('speechSynthesis' in window) {
      const cues = currentPose.customCues || currentPose.cues[0] || `Get ready for ${currentPose.name}`;
      const utterance = new SpeechSynthesisUtterance(cues);
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900 text-white flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-slate-800/50 backdrop-blur-md">
        <div className="flex items-center gap-4">
            <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                <X className="w-6 h-6" />
            </button>
            <div>
                <h1 className="font-bold text-lg">{sequence.title}</h1>
                <p className="text-xs text-slate-400">{currentIndex + 1} / {sequence.poses.length} • {currentPose.name}</p>
            </div>
        </div>
        <div className="flex items-center gap-2">
            <button onClick={() => setShowInfo(!showInfo)} className={`p-2 rounded-full transition-colors ${showInfo ? 'bg-teal-500/20 text-teal-400' : 'hover:bg-white/10'}`}>
                <Info className="w-5 h-5" />
            </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
        
        {/* Main Image Area */}
        <div className="flex-1 relative flex items-center justify-center bg-black/50 p-6">
            <img 
                src={currentPose.imageUrl} 
                alt={currentPose.name} 
                className="max-h-full max-w-full object-contain rounded-lg shadow-2xl"
            />
            
            {/* Timer Overlay */}
            <div className="absolute bottom-8 right-8 bg-black/60 backdrop-blur-md rounded-full px-6 py-3 flex items-center gap-4 border border-white/10">
                <div className="text-3xl font-mono font-bold tracking-wider">{formatTime(timer)}</div>
                <button 
                    onClick={toggleTimer} 
                    className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${isPlaying ? 'bg-yellow-500 text-black' : 'bg-teal-500 text-white hover:bg-teal-400'}`}
                >
                    {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-1" />}
                </button>
                <button onClick={() => setTimer(currentPose.durationSeconds || 60)} className="p-2 text-slate-400 hover:text-white">
                    <RefreshCw className="w-4 h-4" />
                </button>
            </div>
        </div>

        {/* Info Sidebar */}
        {showInfo && (
            <div className="w-full md:w-80 bg-slate-800 border-l border-white/10 p-6 overflow-y-auto animate-in slide-in-from-right duration-300 absolute md:relative right-0 h-full">
                <div className="mb-6">
                    <h2 className="text-2xl font-bold mb-1 text-teal-400">{currentPose.name}</h2>
                    <p className="text-slate-400 italic mb-4">{currentPose.sanskritName}</p>
                    <span className="text-xs bg-slate-700 px-2 py-1 rounded text-slate-300">{currentPose.category}</span>
                </div>

                <div className="space-y-6">
                    <div>
                        <div className="flex justify-between items-center mb-2">
                             <h3 className="font-semibold text-slate-200">Instructions</h3>
                             <button onClick={speakCues} className="text-teal-400 hover:text-teal-300"><Volume2 className="w-4 h-4"/></button>
                        </div>
                        
                        {currentPose.customCues ? (
                             <p className="text-yellow-200 bg-yellow-900/30 p-3 rounded-lg border border-yellow-500/30 text-sm">
                                " {currentPose.customCues} "
                             </p>
                        ) : (
                            <ul className="space-y-2">
                                {currentPose.cues.map((cue, i) => (
                                    <li key={i} className="flex gap-3 text-sm text-slate-300">
                                        <span className="text-teal-500 font-bold">•</span>
                                        {cue}
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>

                    {currentPose.benefits && (
                        <div>
                            <h3 className="font-semibold text-slate-200 mb-2">Benefits</h3>
                            <p className="text-sm text-slate-400 leading-relaxed">{currentPose.benefits}</p>
                        </div>
                    )}
                </div>
            </div>
        )}
      </div>

      {/* Footer Controls */}
      <div className="h-20 bg-slate-800 border-t border-white/10 flex items-center justify-between px-6">
         <Button variant="ghost" className="text-slate-400 hover:text-white" onClick={handlePrev} disabled={currentIndex === 0}>
            <ChevronLeft className="w-5 h-5 mr-2" /> Previous
         </Button>

         <div className="hidden md:flex items-center gap-2">
             {sequence.poses.map((_, i) => (
                 <div 
                    key={i} 
                    className={`h-1.5 rounded-full transition-all duration-300 ${i === currentIndex ? 'w-8 bg-teal-500' : 'w-4 bg-slate-600'}`} 
                 />
             ))}
         </div>

         <div className="flex items-center gap-4">
             {nextPose && (
                 <div className="hidden md:block text-right">
                     <p className="text-[10px] text-slate-500 uppercase tracking-wider">Up Next</p>
                     <p className="text-sm text-slate-300">{nextPose.name}</p>
                 </div>
             )}
             <Button onClick={handleNext} disabled={currentIndex === sequence.poses.length - 1} className="bg-white text-slate-900 hover:bg-slate-200">
                Next <ChevronRight className="w-5 h-5 ml-2" />
             </Button>
         </div>
      </div>
    </div>
  );
};